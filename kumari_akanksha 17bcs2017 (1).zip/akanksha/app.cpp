#include <fstream>
#include <bits/stdc++.h>
#include <sstream>

using namespace std;

class ReplaceWordsInFile
{
    string filepath;
    vector<string> wordsToReplace, wordsToReplaceWith;
    map<string, string> dict;

public:

    ReplaceWordsInFile(string path, vector<string> toReplace, vector<string> replaceWith)
    {
        this->filepath = path;
        this->wordsToReplace = toReplace;
        this->wordsToReplaceWith = replaceWith;
        for(int i = 0; i < wordsToReplace.size(); i++){
            this->dict.insert(pair<string, string>(wordsToReplace[i], wordsToReplaceWith[i]));
        }
    }

    string filter(string word)
    {
        string org = word;
        int s = 0, e = word.size();
        if(!isalpha(word[0])){
            int len = 1;
            while(!isalpha(word[len]))
                len++;
            word.erase(0, len);
            s = len+1;
        }
        int last = word.size();
        if(!isalpha(word[last-1])){
            int len = last-2;
            while(!isalpha(word[len]))
                len--;
            word.erase(len+1);
            e = len+1;
        }
        if(dict.find(word) != dict.end()){
            org.replace(s, e, dict[word]);
        }
        return org;
    }

    void replaceWords()
    {
        ifstream fin;
        ofstream fout;
        string line, word;
        fin.open(this->filepath);
        fout.open("files/output.txt");

        while(fin) {
            getline(fin, line);
            istringstream ss(line);
            while(ss >> word){
                fout << this->filter(word) << " ";
            }
            fout << "\n";
            if(fin.eof()) break;
        }

        fin.close();
        fout.close();
    }

};

int main()
{
    ReplaceWordsInFile obj("files/input.txt", {"One", "Two"}, {"1", "2"});
    obj.replaceWords();
    return 0;
}

