Create an object of the class in main function with file path, words to replace array, words to replace with array as constructor parameters.
Running the file will generate output file inside files directory with name "output.txt"
