import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
 
public class TextFile
{   
    static long replaceWords(String filePath, String[] wordsToReplace, String[] wordsToReplaceWith)
    {
        long count = 0.0;

        File fileToBeModified = new File(filePath);
         
        String oldContent = "";
         
        BufferedReader reader = null;
         
        FileWriter writer = null;
         
        try
        {
            reader = new BufferedReader(new FileReader(fileToBeModified));
             
            //Reading all the lines of input text file into oldContent
             
            String line = reader.readLine();
             
            while (line != null) 
            {
                oldContent = oldContent + line + System.lineSeparator();
                 
                line = reader.readLine();
            }
             
            //Replacing wordsToReplace with wordsToReplaceWith in the oldContent
            String newContent = oldContent;
            for(int i = 0; i<wordsToReplace.length -1; i++) {
                oldContent = oldContent.replaceAll(wordsToReplace[i], wordsToReplaceWith[i]);
            }
             
            //Rewriting the input text file with newContent
             
            writer = new FileWriter(fileToBeModified);
             
            writer.write(oldContent);
            
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        finally
        {
            try
            {
                //Closing the resources
                 
                reader.close();
                 
                writer.close();
            } 
            catch (IOException e) 
            {
                e.printStackTrace();
            }
        }
    }
     
    public static void main(String[] args)
    {
        String[] str1= new String[]{"One", "Two"};
        String[] str2= new String[]{"1","2"};
        replaceWords("C:/myFolder/myFile.txt", str1, str2);
         
        System.out.println("done");
    }
}